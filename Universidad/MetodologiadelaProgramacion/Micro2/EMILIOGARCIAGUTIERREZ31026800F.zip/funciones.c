#include "funciones.h"
void limpiarlinea(char *linea){
	if(linea[strlen(linea)-1]=='\n'){
		 linea[strlen(linea)-1]='\0';
	}
}
int existeFichero(char *fichero){
	FILE *f;
	if((f=fopen(fichero,"r"))==NULL){ 
      		printf("Error: No se pudo abrir el fichero.\n");
      		exit(-1);
  	}
	fclose(f);
}
int contar(char *fichero){
	FILE *f;
	int registros=0;
	char linea[50];
	f=fopen(fichero, "r");
	while(fgets(linea, 50, f)!=NULL){
		registros++;
		limpiarlinea(linea);
	}
	fclose(f);
	return (registros/2);
}
struct Notas *reservaMemoria(int numEle){
  	struct Notas *v;
  	if((v=(struct Notas*)malloc(numEle*sizeof(struct Notas)))==NULL){
      		printf("Error: No se pudo reservar memoria.\n");
      		exit(-1);
  	}
  	return v;
}
struct Alumnos *reservaMemoria2(int numEle){
  	struct notas *v;
  	if((v=(struct Alumnos*)malloc(numEle*sizeof(struct Alumnos)))==NULL){
      		printf("Error: No se pudo reservar memoria.\n");
      		exit(-1);
  	}
  	return v;
}
struct Alumnos *Velementos(char *fichero){
  	FILE *f;
	struct Alumnos *v;
  	if((f=fopen(fichero,"r"))==NULL){ 
      		printf("Error: No se pudo abrir el fichero.\n");
      		exit(-1);
  	}
	char linea[50];
	int nEle=contar(fichero);
	v=(reservaMemoria(nEle));
  	for(int i=0; i<nEle; i++){
		fgets(v[i].nombre, 100, f);
		limpiarlinea(linea);
		fscanf(f, "%f ", &v[i].dni);
	}
	fclose(f);
	return v;
}
struct Notas *Velementos2(char *fichero){
  	FILE *f;
	struct Notas *v;
  	if((f=fopen(fichero,"r"))==NULL){ 
      		printf("Error: No se pudo abrir el fichero.\n");
      		exit(-1);
  	}
	char linea[50];
	int nEle=contar(fichero);
	v=(reservaMemoria2(nEle));
  	for(int i=0; i<nEle; i++){
		fscanf(f, "%f ", &v[i].dni);
		fscanf(f, "%f ", &v[i].nota1);
		fscanf(f, "%f ", &v[i].nota2);
		fscanf(f, "%f ", &v[i].nota3);
	}
	fclose(f);
	return v;
}
float *notam(struct Notas *v){
	float media;
	float vm[5];
  	int suma=0;
  	for(int i=0; i<3; i++){
			suma=(v[i].nota1)+(v[i].nota2)+(v[i].nota3);
			media=(suma/3);
       			vm[i]=media;
  	}
  	return vm;
}
void notafinal(char *fichero, struct Alumnos *v, float *v2){
	FILE *f;
	if((f=fopen(fichero,"w"))==NULL){ 
      		printf("Error: No se pudo abrir el fichero.\n");
      		exit(-1);
  	}
	for(int i=0; i<3; i++){
		fprintf(f, "%s ", v[i].dni);
		fprintf(f, "%s", v[i].nombre);
		fprintf(f, "%f", v2[i]);
	}
	fclose(f);
}
