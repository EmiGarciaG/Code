#ifndef _LIBRERIA_
#define _LIBRERIA_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Alumnos{
	char nombre[100];
	float dni[50];
};
struct Notas{
	float dni[50];
	float nota1;
	float nota2;
	float nota3;
};
void limpiarlinea(char *linea);
int existeFichero(char *fichero);
int contar(char *fichero);
struct Notas *reservaMemoria(int numEle);
struct Alumnos *reservaMemoria2(int numEle);
struct Alumnos *Velementos(char *fichero);
struct Notas *Velementos2(char *fichero);
float notam(struct Notas *v);
void notafinal(char *fichero, struct Alumnos *v, float *v2);
#endif
