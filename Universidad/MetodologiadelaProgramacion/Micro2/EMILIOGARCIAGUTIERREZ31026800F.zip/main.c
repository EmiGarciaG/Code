#include "funciones.h"
int main(int argc, char * argv[]){
	struct Alumnos *v; 
	struct Notas *v2;
	float v3[5];
	if(argc!=3){
      		printf("Error al ejecutar,escriba: %s <notas> <alumnos> <resultado> \n",argv[0]);
      		exit(-1);
   	}
	existefichero(argv[2]);
	existefichero(argv[1]);
	v=Velementos(argv[2]);
	v2=Velementos2(argv[1]);
	v3=notam(v2);
	notafinal(argv[3], v, v3);
	return 0;
}
