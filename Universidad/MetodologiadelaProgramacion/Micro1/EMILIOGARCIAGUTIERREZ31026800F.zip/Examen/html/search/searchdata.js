var indexSectionsWithContent =
{
  0: "fmr",
  1: "fm",
  2: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Archivos",
  2: "Funciones"
};

