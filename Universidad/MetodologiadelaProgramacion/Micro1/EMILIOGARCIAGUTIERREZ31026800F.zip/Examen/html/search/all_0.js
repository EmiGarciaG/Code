var searchData=
[
  ['funciones_2ec',['funciones.c',['../funciones_8c.html',1,'']]],
  ['funciones_2eh',['funciones.h',['../funciones_8h.html',1,'']]]
];
