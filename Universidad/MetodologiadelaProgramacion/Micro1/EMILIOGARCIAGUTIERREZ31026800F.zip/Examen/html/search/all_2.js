var searchData=
[
  ['reservamatriz',['reservaMatriz',['../funciones_8c.html#afcb86ae1306278c15fc19b4ab0cf441f',1,'reservaMatriz(int filas, int columnas):&#160;funciones.c'],['../funciones_8h.html#aa748a452f2f766861526e89f948d2817',1,'reservaMatriz(int filas, int columnas):&#160;funciones.c']]]
];
