var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"},
{text:"Globales",url:"globals.html",children:[
{text:"Todo",url:"globals.html"},
{text:"Funciones",url:"globals_func.html"}]}]}]}
