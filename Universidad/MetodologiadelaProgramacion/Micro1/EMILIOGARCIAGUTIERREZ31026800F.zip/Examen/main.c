/**
@file main.c
@brief cuerpo del programa donde pedimos datos al usuario y devuelve el resultado devuelto por las funciones
*/
#include "funciones.h"
int main(){
	int **matriz;
	int fils=0;
	int cols=0;
	int div;
	int suma;
	printf("\nEscriba numero de filas de la matriz: ");
	scanf("%i", &fils);
	printf("\nEscriba numero de columnas de la matriz: ");
	scanf("%i", &cols);
	matriz=reservaMatriz(fils, cols);
	printf("\nEscriba su matriz: ");
	rellenaMatriz(matriz, fils, cols);
	leeMatriz(matriz, fils, cols);
	divisibles(matriz, fils, cols, &div, &suma);
	printf("\nEl numero de elementos divisibles por 3 es: %i", div);  
	printf("\nLa suma de los elementos divisibles por 3 es: %i\n", suma);  
	liberaMatriz(&matriz, fils);
	return 0;
}
